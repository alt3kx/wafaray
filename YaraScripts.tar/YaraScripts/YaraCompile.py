#!/usr/bin/python3
'''
AUTHORS: 
- Alejandro Hernandez Flores aka alt3kx
- Jesus Huerta Martinez aka mindhack03d
- Israel Zeron aka spk08
DESCRIPTION: Detect and Compile all Yara rules with the extension “yar” or “yara”.
'''
import os, io, yara, re, json

YARA_RULES_PATH="/YaraRules/rules"
YARA_COMPI_PATH="/YaraRules/Compiled"
YARA_DONE_FILES="/YaraRules/yara_compiled.json"
count=0
yara_ext = re.compile("\.ya(r|ra)?$")
yara_files = {}
yara_list={}

#
# COLLECT FILES
#
print("Collecting files")
for root, dir, files in os.walk(YARA_RULES_PATH):
        for lfiles in files:
                if bool(re.search(yara_ext, lfiles)) is True:
                        comp_root= re.sub(YARA_RULES_PATH, YARA_COMPI_PATH, root)
                        # Create Dir if it doesn't exist.
                        if bool(os.path.exists(comp_root)) is False:
                                os.makedirs(comp_root)
                        yara_files[count]={'yr_dir':root, 'yr_rule':lfiles, 'yr_full': root + "/" +lfiles,
                                           'cr_dir':comp_root, 'cr_rule':lfiles, 'cr_full': comp_root + "/" + lfiles, 'compiled':False}
                        count+=1

#
# COMPILE FILES
#
print("Compiling Yara Rules")
count=0
for yf_count in yara_files:
        or_yara_rule=yara_files[yf_count]['yr_full']
        co_yara_rule=yara_files[yf_count]['cr_full']
        rules=""
        try:
                rules = yara.compile(or_yara_rule)
                rules.save(co_yara_rule)
                yara_files[yf_count]['compiled']=True
                yara_list[count]=co_yara_rule
                count+=1
        except:
                yara_files[yf_count]['compiled']=False

#
# CLEAN FILE
#
if bool(os.path.exists(YARA_DONE_FILES)) is True:
        os.remove(YARA_DONE_FILES)

#
# WRITE JSON FILE
#
with open(YARA_DONE_FILES, 'w') as outfile:
        json.dump(yara_list, outfile)

#
# PRINT ERROR
#
err_array=[]
for err_count in yara_files:
        if yara_files[yf_count]['compiled'] is False:
                err_array.append(yara_files[yf_count]['yr_full'])
err_array=sorted(set(err_array))
for err_c in err_array:
        print("Error found in:" + err_c)


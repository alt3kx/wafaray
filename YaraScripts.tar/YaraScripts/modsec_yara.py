#!/usr/bin/python3
'''
AUTHOR: 
- Alejandro Hernandez Flores aka alt3kx
- Jesus Huerta Martinez aka mindhack03d
- Israel Zeron Medina aka spk08
DESCRIPTION: Load yara rule by yara rule and inspect the file.
IF the file is identified with one yara rule, the result is 
“0 SUSPECTED” and this result is share with ModSecurity and 
the result of the request is deny.
'''
import yara, sys, os, io, json, time

# Main MSG
msg_ok = "1 OK"
msg_nok = "0 SUSPECTED"
msg_full=""
YARA_COMPILE_FILE="/YaraRules/yara_compiled.json"

#Input from ModSecurity
sinput = sys.argv[1]

# Upload YARA Compiled Rules
try:
	with open(YARA_COMPILE_FILE) as json_yara_rules:
	        yara_com_files = json.load(json_yara_rules)
	for key_yrules in yara_com_files:
	        exec_rule=yara.load(yara_com_files[key_yrules])
	        if bool(exec_rule.match(sinput)) is True:
	                out = exec_rule.match(sinput)
	                msg_full = msg_nok + " [YaraSignature: " + str(out[0]) + "]"
	                break
	        else:
	                msg_full = msg_ok
except:
	msg_full = msg_ok + "[Yara Failed]"
print(msg_full)
